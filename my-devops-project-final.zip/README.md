# My DevOps Project

This is my first DevOps practice project